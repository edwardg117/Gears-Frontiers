# replace_ids.ps1
# Replaces every occurrence of "REPLACEME" in challenges.snbt
# with a unique random 16-digit hexadecimal ID.

$filePath = Join-Path $PSScriptRoot "quests\chapters\challenges.snbt"

if (-not (Test-Path $filePath)) {
    Write-Error "File not found: $filePath"
    exit 1
}

$content = Get-Content -Path $filePath -Raw

$usedIds = [System.Collections.Generic.HashSet[string]]::new()

$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$bytes = New-Object byte[] 8

$newContent = [System.Text.RegularExpressions.Regex]::Replace(
    $content,
    '"REPLACEME"',
    {
        do {
            $rng.GetBytes($bytes)
            $hex = [System.BitConverter]::ToString($bytes) -replace '-', ''
            $hex = $hex.ToUpper()
        } while (-not $usedIds.Add($hex))

        return "`"$hex`""
    }
)

Set-Content -Path $filePath -Value $newContent -NoNewline -Encoding UTF8

Write-Host "Done! Replaced $($usedIds.Count) occurrence(s) with unique 16-digit hex IDs."

