#!/usr/bin/env python3
"""
Script to add 'disable_toast: true' to all tasks in a specific quest in challenges.snbt

This script doesn't work :(
"""

import re
import sys

def read_snbt_file(filepath):
    """Read the SNBT file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

def write_snbt_file(filepath, content):
    """Write the SNBT file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

def find_quest_by_id(content, quest_id):
    """Find a quest block by its ID."""
    # Pattern to match a quest with the given ID
    pattern = rf'(\{{\s*(?:[^{{}}]*?\n)*?\s*id:\s*"{quest_id}".*?(?=\n\s*\}})'
    match = re.search(pattern, content, re.DOTALL)
    return match

def add_disable_toast_to_quest(content, quest_id):
    """Add disable_toast: true to all tasks in a quest."""
    # Find the quest
    quest_match = re.search(
        rf'(\{{\s*(?:[^{{}}]*?\n)*?\s*id:\s*"{quest_id}".*?)(\n\s*\}})',
        content,
        re.DOTALL
    )
    
    if not quest_match:
        return None, "Quest not found"
    
    quest_start = quest_match.start()
    quest_end = quest_match.end()
    quest_content = quest_match.group(1)
    
    # Find all tasks in this quest
    tasks_pattern = r'tasks:\s*\[(.*?)\](?=\s*(?:x:|y:|dependencies:|id:|shape:|}|$))'
    tasks_match = re.search(tasks_pattern, quest_content, re.DOTALL)
    
    if not tasks_match:
        return None, "No tasks found in quest"
    
    tasks_section = tasks_match.group(0)
    tasks_start_in_quest = quest_match.start(1) + tasks_match.start()
    
    # Process each task
    modified_tasks = tasks_section
    task_count = 0
    
    # Find all individual task blocks
    task_pattern = r'(\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\})'
    for task_match in re.finditer(task_pattern, tasks_match.group(1)):
        task_block = task_match.group(1)
        
        # Check if disable_toast is already present
        if 'disable_toast:' not in task_block:
            # Add disable_toast: true before the closing brace
            modified_task = task_block.rstrip() + '\n\t\t\t\tdisable_toast: true\n\t\t\t}'
            modified_tasks = modified_tasks.replace(task_block, modified_task, 1)
            task_count += 1
    
    # Replace in original content
    new_content = content[:tasks_start_in_quest] + modified_tasks + content[tasks_start_in_quest + len(tasks_section):]
    
    return new_content, f"Added disable_toast: true to {task_count} task(s)"

def main():
    filepath = "quests/chapters/challenges.snbt"
    
    try:
        content = read_snbt_file(filepath)
    except FileNotFoundError:
        print(f"Error: File '{filepath}' not found")
        sys.exit(1)
    
    # Ask for quest ID
    quest_id = input("Enter the quest ID: ").strip()
    
    if not quest_id:
        print("Error: Quest ID cannot be empty")
        sys.exit(1)
    
    # Add disable_toast to the quest
    new_content, message = add_disable_toast_to_quest(content, quest_id)
    
    if new_content is None:
        print(f"Error: {message}")
        sys.exit(1)
    
    # Write back to file
    write_snbt_file(filepath, new_content)
    print(f"Success: {message}")
    print(f"File '{filepath}' has been updated")

if __name__ == "__main__":
    main()

